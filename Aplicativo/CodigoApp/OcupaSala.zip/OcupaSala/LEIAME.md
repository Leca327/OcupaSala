# OcupaSala — App Android

Aplicativo que recebe, via Bluetooth Clássico (HC-05), a contagem de pessoas enviada pelo Arduino
e exibe a ocupação da sala de estudos em tempo real. Funciona 100% offline.

## Formato esperado das mensagens

Cada mensagem deve terminar com quebra de linha (use `Serial.println` / `bt.println` no Arduino):

    Ocupacao: ENTRADA - 4 PESSOAS
    Ocupacao: SAIDA - 3 PESSOAS

O app lê o número antes de "PESSOAS" como total atual na sala e identifica ENTRADA/SAIDA
para mostrar a última movimentação. A capacidade (5) fica em `CAPACIDADE_MAXIMA`,
no arquivo `OcupaViewModel.kt`.

## Opção A — Gerar o APK no Android Studio

1. Instale o Android Studio (developer.android.com/studio).
2. File > Open > selecione a pasta `OcupaSala`. Aguarde o Gradle sincronizar (precisa de internet só nessa etapa).
3. Menu Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Clique em "locate" na notificação. O arquivo é `app/build/outputs/apk/debug/app-debug.apk`.
5. Envie o APK para o celular (cabo, WhatsApp, Drive) e instale, permitindo "instalar apps desconhecidos".

Alternativa: com o celular ligado por cabo e a Depuração USB ativada, basta clicar em ▶ Run.

## Opção B — Gerar o APK sem instalar nada (GitHub)

1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive a pasta oculta `.github`).
2. Abra a aba Actions do repositório. O workflow "Gerar APK" roda sozinho (~5 min).
3. Ao terminar, baixe o artefato "OcupaSala-apk" no fim da página da execução e instale no celular.

## Uso

1. Ligue o Arduino. No celular, vá em Configurações > Bluetooth e pareie o HC-05 (senha 1234 ou 0000).
2. Abra o OcupaSala, toque em "Conectar ao Arduino", permita o acesso ao Bluetooth e escolha o HC-05.
3. Nas próximas vezes, o app reconecta sozinho ao último módulo usado.

## Dicas para a apresentação

- Feche o monitor serial / script Python do computador: o HC-05 aceita só uma conexão por vez.
- A tela permanece acesa enquanto o app estiver aberto.
- Se a conexão cair, toque em "Reconectar".
- A linha "Última mensagem recebida" no rodapé mostra o texto bruto do Arduino, útil para conferir se os dados estão chegando.
