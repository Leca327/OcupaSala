package br.com.ocupasala

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Capacidade máxima da sala de estudos. */
const val CAPACIDADE_MAXIMA = 5

/** UUID padrão do perfil serial (SPP), usado pelo HC-05. */
private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

enum class StatusConexao { DESCONECTADO, CONECTANDO, CONECTADO, FALHOU }

data class Dispositivo(val nome: String, val endereco: String)

data class EstadoTela(
    val status: StatusConexao = StatusConexao.DESCONECTADO,
    val nomeDispositivo: String? = null,
    val pessoas: Int = 0,
    val ultimoEvento: String? = null,      // "ENTRADA" ou "SAIDA"
    val horaUltimoEvento: String? = null,
    val ultimaMensagem: String? = null,    // texto bruto recebido (ajuda em testes)
    val erro: String? = null,
)

class OcupaViewModel(app: Application) : AndroidViewModel(app) {

    private val _estado = MutableStateFlow(EstadoTela())
    val estado: StateFlow<EstadoTela> = _estado.asStateFlow()

    private val adaptador: BluetoothAdapter? =
        (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private val prefs = app.getSharedPreferences("ocupasala", Context.MODE_PRIVATE)

    private var socket: BluetoothSocket? = null
    private var tarefaLeitura: Job? = null

    // Captura o número antes de "PESSOA(S)", ex.: "Ocupacao: ENTRADA - 4 PESSOAS"
    private val regexPessoas = Regex("""(\d+)\s*PESSOA""", RegexOption.IGNORE_CASE)

    fun bluetoothDisponivel() = adaptador != null
    fun bluetoothLigado() = adaptador?.isEnabled == true
    fun ultimoEndereco(): String? = prefs.getString("ultimo_dispositivo", null)

    @SuppressLint("MissingPermission")
    fun dispositivosPareados(): List<Dispositivo> =
        adaptador?.bondedDevices.orEmpty()
            .map { Dispositivo(it.name ?: "Sem nome", it.address) }
            // HC-05 aparece primeiro na lista
            .sortedByDescending { it.nome.contains("HC", ignoreCase = true) }

    @SuppressLint("MissingPermission")
    fun conectar(endereco: String) {
        val bt = adaptador ?: return
        desconectar()
        val dispositivo = bt.getRemoteDevice(endereco)
        prefs.edit().putString("ultimo_dispositivo", endereco).apply()

        _estado.update {
            it.copy(
                status = StatusConexao.CONECTANDO,
                nomeDispositivo = dispositivo.name ?: endereco,
                erro = null,
            )
        }

        tarefaLeitura = viewModelScope.launch(Dispatchers.IO) {
            var local: BluetoothSocket? = null
            try {
                bt.cancelDiscovery()
                val s = abrirSocket(dispositivo)
                local = s
                if (!isActive) { s.close(); return@launch }
                socket = s
                _estado.update { it.copy(status = StatusConexao.CONECTADO) }

                val leitor = BufferedReader(InputStreamReader(s.inputStream, Charsets.ISO_8859_1))
                while (isActive) {
                    val linha = leitor.readLine() ?: break   // null = conexão encerrada
                    processarLinha(linha)
                }
                throw IOException("Conexão encerrada")
            } catch (e: Exception) {
                if (isActive) {
                    _estado.update {
                        it.copy(
                            status = StatusConexao.FALHOU,
                            erro = "Não foi possível manter a conexão. Verifique se o Arduino está ligado e próximo.",
                        )
                    }
                }
                runCatching { local?.close() }
            }
        }
    }

    /** Tenta o método padrão; se falhar, usa o canal 1 (contorna problemas em alguns aparelhos). */
    @SuppressLint("MissingPermission")
    private fun abrirSocket(dispositivo: BluetoothDevice): BluetoothSocket {
        val padrao = dispositivo.createRfcommSocketToServiceRecord(SPP_UUID)
        return try {
            padrao.connect()
            padrao
        } catch (e: IOException) {
            runCatching { padrao.close() }
            val metodo = dispositivo.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            val alternativo = metodo.invoke(dispositivo, 1) as BluetoothSocket
            alternativo.connect()
            alternativo
        }
    }

    private fun processarLinha(bruta: String) {
        val linha = bruta.trim()
        if (linha.isEmpty()) return

        val quantidade = regexPessoas.find(linha)?.groupValues?.get(1)?.toIntOrNull()
        if (quantidade == null) {
            _estado.update { it.copy(ultimaMensagem = linha) }
            return
        }

        val evento = when {
            linha.contains("ENTRADA", ignoreCase = true) -> "ENTRADA"
            linha.contains("SAIDA", ignoreCase = true) ||
                linha.contains("SAÍDA", ignoreCase = true) -> "SAIDA"
            else -> null
        }
        val hora = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR")).format(Date())

        _estado.update {
            it.copy(
                pessoas = quantidade.coerceAtLeast(0),
                ultimoEvento = evento ?: it.ultimoEvento,
                horaUltimoEvento = hora,
                ultimaMensagem = linha,
            )
        }
    }

    fun desconectar() {
        tarefaLeitura?.cancel()
        tarefaLeitura = null
        fecharSocket()
        _estado.update { it.copy(status = StatusConexao.DESCONECTADO, erro = null) }
    }

    private fun fecharSocket() {
        runCatching { socket?.close() }
        socket = null
    }

    override fun onCleared() {
        desconectar()
        super.onCleared()
    }
}
