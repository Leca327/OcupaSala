package br.com.ocupasala

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

// ---------- Paleta ----------
object Cores {
    val Fundo = Color(0xFF0B1E3D)
    val Cartao = Color(0xFF132C54)
    val CartaoClaro = Color(0xFF1C3A6B)
    val Trilha = Color(0xFF233F6E)
    val Verde = Color(0xFF22C55E)
    val Amarelo = Color(0xFFF59E0B)
    val Vermelho = Color(0xFFEF4444)
    val Branco = Color.White
    val Suave = Color(0xFFA9B8D3)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Mantém a tela acesa durante a apresentação
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            // Mantém o layout fiel ao protótipo mesmo com fonte grande no celular
            val densidade = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(densidade.density, fontScale = densidade.fontScale.coerceAtMost(1f))
            ) {
                MaterialTheme(colorScheme = darkColorScheme(primary = Cores.Verde, surface = Cores.Cartao)) {
                    TelaOcupaSala()
                }
            }
        }
    }
}

fun temPermissaoBluetooth(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    else true

@Composable
fun TelaOcupaSala(vm: OcupaViewModel = viewModel()) {
    val ctx = LocalContext.current
    val estado by vm.estado.collectAsStateWithLifecycle()
    var mostrarLista by remember { mutableStateOf(false) }

    val pedirLigarBt = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (vm.bluetoothLigado()) mostrarLista = true }

    val pedirPermissao = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedida ->
        if (!concedida) {
            Toast.makeText(ctx, "Permissão de Bluetooth necessária para conectar.", Toast.LENGTH_LONG).show()
        } else if (!vm.bluetoothLigado()) {
            pedirLigarBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        } else {
            mostrarLista = true
        }
    }

    fun iniciarConexao() {
        when {
            !vm.bluetoothDisponivel() ->
                Toast.makeText(ctx, "Este aparelho não possui Bluetooth.", Toast.LENGTH_LONG).show()
            !temPermissaoBluetooth(ctx) ->
                pedirPermissao.launch(Manifest.permission.BLUETOOTH_CONNECT)
            !vm.bluetoothLigado() ->
                pedirLigarBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            else -> mostrarLista = true
        }
    }

    // Ao abrir o app, reconecta automaticamente ao último HC-05 usado
    LaunchedEffect(Unit) {
        val ultimo = vm.ultimoEndereco()
        if (ultimo != null && temPermissaoBluetooth(ctx) && vm.bluetoothLigado() &&
            vm.dispositivosPareados().any { it.endereco == ultimo }
        ) {
            vm.conectar(ultimo)
        }
    }

    val pessoas = estado.pessoas
    val vagas = (CAPACIDADE_MAXIMA - pessoas).coerceAtLeast(0)
    val percentual = pessoas * 100 / CAPACIDADE_MAXIMA
    val lotada = pessoas >= CAPACIDADE_MAXIMA
    val corNivel = when {
        lotada -> Cores.Vermelho
        pessoas >= CAPACIDADE_MAXIMA - 1 -> Cores.Amarelo
        else -> Cores.Verde
    }
    val corAnimada by animateColorAsState(corNivel, tween(500), label = "cor")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Cores.Fundo)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Cabecalho()
        ChipConexao(estado)

        AnimatedVisibility(
            visible = lotada,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
        ) { AlertaLotada(pessoas) }

        // Medidor principal
        Cartao {
            Column(
                Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Ocupação atual", color = Cores.Suave, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                MedidorCircular(pessoas, CAPACIDADE_MAXIMA, corAnimada)
                Text(
                    textoNivel(pessoas),
                    color = corAnimada,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartaoIndicador("Vagas disponíveis", "$vagas", Cores.Verde, Modifier.weight(1f))
            CartaoIndicador("Ocupação", "$percentual%", corAnimada, Modifier.weight(1f))
        }

        CartaoUltimoEvento(estado)

        BotaoConexao(
            estado = estado,
            aoConectar = { iniciarConexao() },
            aoDesconectar = { vm.desconectar() },
        )

        estado.ultimaMensagem?.let {
            Text(
                "Última mensagem recebida: $it",
                color = Cores.Suave.copy(alpha = 0.7f),
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
        }
    }

    if (mostrarLista) {
        DialogoDispositivos(
            dispositivos = vm.dispositivosPareados(),
            aoEscolher = { mostrarLista = false; vm.conectar(it.endereco) },
            aoAbrirConfiguracoes = {
                mostrarLista = false
                ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            },
            aoFechar = { mostrarLista = false },
        )
    }
}

fun textoNivel(pessoas: Int) = when {
    pessoas > CAPACIDADE_MAXIMA -> "Acima da capacidade"
    pessoas == CAPACIDADE_MAXIMA -> "Sala lotada"
    pessoas == CAPACIDADE_MAXIMA - 1 -> "Quase cheia"
    pessoas == 0 -> "Sala livre"
    else -> "Vagas disponíveis"
}

// ---------- Componentes ----------

@Composable
fun Cabecalho() {
    Column {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = Cores.Branco)) { append("Ocupa") }
                withStyle(SpanStyle(color = Cores.Verde)) { append("Sala") }
            },
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text("Sala de estudos · Biblioteca", color = Cores.Suave, fontSize = 13.sp)
    }
}

@Composable
fun Cartao(modifier: Modifier = Modifier, conteudo: @Composable () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Cores.Cartao)
            .padding(16.dp)
    ) { conteudo() }
}

@Composable
fun ChipConexao(estado: EstadoTela) {
    val (cor, texto) = when (estado.status) {
        StatusConexao.CONECTADO -> Cores.Verde to "Conectado · ${estado.nomeDispositivo ?: "HC-05"}"
        StatusConexao.CONECTANDO -> Cores.Amarelo to "Conectando a ${estado.nomeDispositivo ?: "HC-05"}…"
        StatusConexao.FALHOU -> Cores.Vermelho to "Conexão perdida"
        StatusConexao.DESCONECTADO -> Cores.Suave to "Bluetooth desconectado"
    }
    val pulso = rememberInfiniteTransition(label = "pulso")
    val alfa by pulso.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "alfa",
    )
    Column {
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Cores.Cartao)
                .border(1.dp, cor.copy(alpha = 0.4f), RoundedCornerShape(50))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(10.dp)
                    .alpha(if (estado.status == StatusConexao.CONECTANDO) alfa else 1f)
                    .clip(CircleShape)
                    .background(cor)
            )
            Spacer(Modifier.width(8.dp))
            Text(texto, color = Cores.Branco, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        estado.erro?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = Cores.Vermelho, fontSize = 12.sp)
        }
    }
}

@Composable
fun AlertaLotada(pessoas: Int) {
    val pulso = rememberInfiniteTransition(label = "alerta")
    val alfa by pulso.animateFloat(
        initialValue = 0.75f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alfaAlerta",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(alfa)
            .clip(RoundedCornerShape(16.dp))
            .background(Cores.Vermelho)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = Cores.Branco, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Sala lotada!", color = Cores.Branco, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(
                if (pessoas > CAPACIDADE_MAXIMA) "$pessoas pessoas — acima da capacidade de $CAPACIDADE_MAXIMA."
                else "Capacidade máxima de $CAPACIDADE_MAXIMA pessoas atingida.",
                color = Cores.Branco, fontSize = 13.sp,
            )
        }
    }
}

@Composable
fun MedidorCircular(pessoas: Int, capacidade: Int, cor: Color) {
    val alvo = (pessoas.toFloat() / capacidade).coerceIn(0f, 1f)
    val progresso by animateFloatAsState(alvo, tween(700), label = "progresso")

    Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val espessura = 18.dp.toPx()
            val tamanho = Size(size.width - espessura, size.height - espessura)
            val origem = Offset(espessura / 2, espessura / 2)
            drawArc(
                color = Cores.Trilha, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = origem, size = tamanho, style = Stroke(espessura, cap = StrokeCap.Round),
            )
            if (progresso > 0f) {
                drawArc(
                    color = cor, startAngle = 135f, sweepAngle = 270f * progresso, useCenter = false,
                    topLeft = origem, size = tamanho, style = Stroke(espessura, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Cores.Branco, fontSize = 52.sp, fontWeight = FontWeight.SemiBold)) {
                        append("$pessoas")
                    }
                    withStyle(SpanStyle(color = Cores.Suave, fontSize = 24.sp)) { append("/$capacidade") }
                }
            )
            Text("pessoas na sala", color = Cores.Suave, fontSize = 12.sp)
        }
    }
}

@Composable
fun CartaoIndicador(titulo: String, valor: String, cor: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Cores.Cartao)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(titulo, color = Cores.Suave, fontSize = 12.sp, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text(valor, color = cor, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun CartaoUltimoEvento(estado: EstadoTela) {
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Cores.CartaoClaro),
                contentAlignment = Alignment.Center,
            ) {
                when (estado.ultimoEvento) {
                    "ENTRADA" -> Icon(Icons.Filled.KeyboardArrowUp, null, tint = Cores.Verde, modifier = Modifier.size(26.dp))
                    "SAIDA" -> Icon(Icons.Filled.KeyboardArrowDown, null, tint = Cores.Branco, modifier = Modifier.size(26.dp))
                    else -> Box(Modifier.size(8.dp).clip(CircleShape).background(Cores.Suave))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Última movimentação", color = Cores.Suave, fontSize = 12.sp)
                Text(
                    when (estado.ultimoEvento) {
                        "ENTRADA" -> "Entrada às ${estado.horaUltimoEvento}"
                        "SAIDA" -> "Saída às ${estado.horaUltimoEvento}"
                        else -> "Aguardando dados do sensor"
                    },
                    color = Cores.Branco, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}

@Composable
fun BotaoConexao(estado: EstadoTela, aoConectar: () -> Unit, aoDesconectar: () -> Unit) {
    val conectadoOuConectando =
        estado.status == StatusConexao.CONECTADO || estado.status == StatusConexao.CONECTANDO
    if (conectadoOuConectando) {
        OutlinedButton(
            onClick = aoDesconectar,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cores.Branco),
        ) { Text("Desconectar", fontSize = 16.sp) }
    } else {
        Button(
            onClick = aoConectar,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cores.Verde, contentColor = Cores.Fundo),
        ) {
            Text(
                if (estado.status == StatusConexao.FALHOU) "Reconectar" else "Conectar ao Arduino",
                fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
fun DialogoDispositivos(
    dispositivos: List<Dispositivo>,
    aoEscolher: (Dispositivo) -> Unit,
    aoAbrirConfiguracoes: () -> Unit,
    aoFechar: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = aoFechar,
        containerColor = Cores.Cartao,
        title = { Text("Escolha o módulo Bluetooth", color = Cores.Branco) },
        text = {
            if (dispositivos.isEmpty()) {
                Text(
                    "Nenhum dispositivo pareado. Pareie o HC-05 nas configurações de Bluetooth " +
                        "do celular (senha padrão 1234 ou 0000) e volte ao app.",
                    color = Cores.Suave,
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    dispositivos.forEach { d ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Cores.CartaoClaro)
                                .clickable { aoEscolher(d) }
                                .padding(14.dp)
                        ) {
                            Text(d.nome, color = Cores.Branco, fontWeight = FontWeight.SemiBold)
                            Text(d.endereco, color = Cores.Suave, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = aoAbrirConfiguracoes) { Text("Parear novo", color = Cores.Verde) }
        },
        dismissButton = {
            TextButton(onClick = aoFechar) { Text("Cancelar", color = Cores.Suave) }
        },
    )
}
